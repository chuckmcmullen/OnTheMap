//
//  LoctionResponse.swift
//  OnTheMap
//
//  Created by Chuck McMullen on 2/21/21.
//

import Foundation
struct LocationResponse: Codable {
    
    let createdAt:String
    let objectId: String
    
    
    enum CodingKeys: String, CodingKey
    {
        case createdAt = "createdAt"
        case objectId = "objectId"
        
        
    }
    
}
