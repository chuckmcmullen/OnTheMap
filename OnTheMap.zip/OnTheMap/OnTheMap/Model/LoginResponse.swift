//
//  LoginResponse.swift
//  OnTheMap
//
//  Created by Chuck McMullen on 3/15/21.
//

import Foundation
struct LoginResponse: Codable {
    let registered:Account
    let session: Session
    let statusMessage: String
    
    enum CodingKeys: String, CodingKey
    {
        case registered = "registered"
        case session = "session"
        case statusMessage = "statusMessage"
    }
    
}
extension LoginResponse: LocalizedError {
    var errorDescription: String? {
        return statusMessage
    }
}
