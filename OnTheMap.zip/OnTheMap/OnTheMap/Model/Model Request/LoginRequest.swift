//
//  Login.swift
//  OnTheMap
//
//  Created by Chuck McMullen on 2/19/21.
//

import Foundation
struct LoginRequest: Codable {
    
    let username:String
    let password: String
    
    enum CodingKeys: String, CodingKey
    {
        case username = "username"
        case password = "password"
        
        
    }
    
}
