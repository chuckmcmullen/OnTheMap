//
//  Student.swift
//  OnTheMap
//
//  Created by Chuck McMullen on 2/16/21.
//

import Foundation
class StudentModel {
    
    static var studentlist = [Student]()
    
    
}
