//
//  RequestResponse.swift
//  OnTheMap
//
//  Created by Chuck McMullen on 2/19/21.
//

import Foundation
struct RequestResponse: Codable {
    let account:Account
    let session: Session
    
    
    enum CodingKeys: String, CodingKey
    {
        case account = "account"
        case session = "session"
        
        
    }
    
}
