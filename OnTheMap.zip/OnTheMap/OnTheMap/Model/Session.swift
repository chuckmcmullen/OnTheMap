//
//  Session.swift
//  OnTheMap
//
//  Created by Chuck McMullen on 2/19/21.
//

import Foundation
struct Session: Codable {
    
    let id:String
    let expiration: String
    
    
    enum CodingKeys: String, CodingKey
    {
        case id = "id"
        case expiration = "expiration"
        
        
    }
    
}
