//
//  MapClient.swift
//  OnTheMap
//
//  Created by Chuck McMullen on 2/16/21.
//

import Foundation
class MapClient {
    
    static let apiKey = "97e1cabed8a6c6386eca9217f7472f6b"
    //var myAccount:RequestResponse
    struct Auth {
        static var accountId = 0
        static var requestToken = ""
        static var sessionId = ""
    }
    
    enum Endpoints {
        static let base = "https://onthemap-api.udacity.com/v1"
        //static let apiKeyParam = "?api_key=\(TMDBClient.apiKey)"
        
        case getStudentlist
        case getUdacity
        
        
        var stringValue: String {
            switch self {
            case .getStudentlist: return Endpoints.base + "/StudentLocation?limit=100&order=-updatedAt"
            case .getUdacity: return Endpoints.base + "/session"
            
            }
            
        }
        
        var url: URL {
            return URL(string: stringValue)!
        }
    }
    class func login(username:String,password:String,completion: @escaping(String,Bool,Error?) -> Void)
    {
        let body = LoginRequest(username:username,password: password)
        taskForPOSTRequest(url: Endpoints.getUdacity.url, responseType: RequestResponse.self, body: body,username:username,password:password) { (response, error) in
            if let response = response {
                //self.myAccount = response.account
                print("Token 2 test sessionid \(response.session.id)")
                               
                completion(response.session.id,true, nil)
            } else {
                completion("",false, error)
                print("error llogin")
                
                
            }
            
        }
        
        
    }
    class func logout(sessionID:String,completion: @escaping(Bool,Error?) -> Void)
    {
        taskForDELETERequest(url: Endpoints.getUdacity.url, responseType: LogoutResponse.self,sessionID: sessionID) { (response, error) in
            if let response = response {
                //self.myAccount = response.account
                print("Logout was Sucessful sessionid \(response.session.id)")
                               
                completion(true, nil)
            } else {
                completion(false, error)
                print("error logging out")
                
                
            }
            
        }    }

    class func getStudentlist(completion: @escaping ([Student], Error?) -> Void) {
        taskForGETRequest(url: Endpoints.getStudentlist.url, responseType:
                           StudentResults.self) { (response, error) in
           if let response = response {
            
                completion(response.results, nil)
            
           } else {
               completion([], error)
           }
        }
        
    }
    class func addStudentLoction(location:String, lat:String,lon:String,urlString:String,completion: @escaping (LocationResponse?, Error?) -> Void)
    {
        var request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/StudentLocation")!)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = "{\"uniqueKey\": \"1234\", \"firstName\": \"James\", \"lastName\": \"Craig\",\"mapString\": \"\(location)\", \"mediaURL\": \"\(urlString)\",\"latitude\": \(lat), \"longitude\": \(lon)}".data(using: .utf8)
        //request.httpBody = "{\"uniqueKey\": \"1234\", \"firstName\": \"James\", \"lastName\": \"Craig\",\"mapString\": \"Willoughby, OH\", \"mediaURL\": \"https://yahoo.com\",\"latitude\": 41.61510, \"longitude\": -81.44590}".data(using: .utf8)
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            guard let data = data else {
                DispatchQueue.main.async {
                    completion(nil, error)
                }
                return
            }
            let decoder = JSONDecoder()
            do {
                let responseObject = try decoder.decode(LocationResponse.self, from: data)
                DispatchQueue.main.async {
                    completion(responseObject, nil)
                }
            } catch {
                DispatchQueue.main.async {
                    completion(nil, error)
                }
                
            }
            /**if error != nil { // Handle error…
            print("Error in addStudentLoction")
            return
          }
          print("success in addStudentLoction")
          print(String(data: data!, encoding: .utf8)!)**/
            
            
            
        }
        task.resume()
        
    }
    class func updateStudentLoction(objectID:String)
    {
        let urlString = "https://onthemap-api.udacity.com/v1/StudentLocation/" + objectID
        let url = URL(string: urlString)
        var request = URLRequest(url: url!)
        request.httpMethod = "PUT"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = "{\"uniqueKey\": \"1234\", \"firstName\": \"Chuck\", \"lastName\": \"McMullen\",\"mapString\": \"Willoughby, OH\", \"mediaURL\": \"https://yahoo.com\",\"latitude\": 41.61510, \"longitude\": -81.44590}".data(using: .utf8)
        //request.httpBody = "{\"uniqueKey\": \"1234\", \"firstName\": \"Chuck\", \"lastName\": \"McMullen\",\"mapString\": \"Willoughby, OH\", \"mediaURL\": \"https://yahoo.com\",\"latitude\": 41.61510, \"longitude\": -81.44590}".data(using: .utf8)
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if error != nil { // Handle error…
            print("Error in updxateStudentLoction")
            return
          }
            print("success in updateStudentLoction")
            print(String(data: data!, encoding: .utf8)!)
            
          
        }
        task.resume()
        
    }
    class func taskForGETRequest<ResponseType: Decodable>(url: URL, responseType: ResponseType.Type, completion: @escaping (ResponseType?, Error?) -> Void)
    {
        let task = URLSession.shared.dataTask(with: url) { data, responseType, error in
            guard let data = data else {
                DispatchQueue.main.async {
                    completion(nil, error)
                }
                return
            }
            let decoder = JSONDecoder()
            do {
                let responseObject = try decoder.decode(ResponseType.self, from: data)
                DispatchQueue.main.async {
                    completion(responseObject, nil)
                }
            } catch {
                DispatchQueue.main.async {
                    completion(nil, error)
                }
                
            }
        }
        task.resume()
        
    }
    class func taskForPOSTRequest<RequestType: Encodable, ResponseType: Decodable>(url: URL, responseType: ResponseType.Type,body: RequestType,username:String,password:String, completion: @escaping (ResponseType?, Error?) -> Void)
    {
        var request = URLRequest(url:url)
        print(url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        //request.httpBody = try! JSONEncoder().encode(body)
        request.httpBody = "{\"udacity\": {\"username\": \"\(username)\", \"password\": \"\(password)\"}}".data(using: .utf8)
         
        
        //request.httpBody = tempString.data(using: .utf8)
        
        let session = URLSession.shared
        let task = session.dataTask(with: request) { (data, response, error) in
            if error != nil { // Handle error…
                return
            }
            let range = (5..<data!.count)
            let newData = data?.subdata(in: range) /* subset response data! */
            print("Follow")
            print(String(data: newData!, encoding: .utf8)!)
            //*****************
            guard let data = newData else {
                DispatchQueue.main.async {
                    print("here1")
                    completion(nil, error)
                }
                return
            }
            let decoder = JSONDecoder()
            do {
                let responseObject = try decoder.decode(responseType.self, from: data)
                DispatchQueue.main.async {
                    print("here2")
                    print(responseObject)
                    completion(responseObject, nil)
                }
            } catch {
                do {
                    let errorResponse = try decoder.decode(LoginErrorResponse.self, from: data) as Error 
                    DispatchQueue.main.async {
                        print("here3")
                        print(errorResponse)
                        completion(nil, errorResponse)
                        
                    }
                } catch {
                    //let errorResponse1 = try decoder.decode(LoginErrorResponse.self, from: data) as Error
                    DispatchQueue.main.async {
                        print("here 4")
                        completion(nil, error)
                        
                    }
                }
            }
            
            //*****************
            
              
        }
        task.resume()
        
    }
    class func taskForDELETERequest<ResponseType: Decodable>(url: URL, responseType: ResponseType.Type,sessionID:String, completion: @escaping (LogoutResponse?, Error?) -> Void)
    {
        var request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/session")!)
        request.httpMethod = "DELETE"
        var xsrfCookie: HTTPCookie? = nil
        let sharedCookieStorage = HTTPCookieStorage.shared
        for cookie in sharedCookieStorage.cookies! {
          if cookie.name == sessionID { xsrfCookie = cookie }
        }
        if let xsrfCookie = xsrfCookie {
          request.setValue(xsrfCookie.value, forHTTPHeaderField: sessionID)
        }
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
          if error != nil { // Handle error…
              return
          }
          let range = (5..<data!.count)
          let newData = data?.subdata(in: range) /* subset response data! */
          print(String(data: newData!, encoding: .utf8)!)
            //*****************
            guard let data = newData else {
                DispatchQueue.main.async {
                    print("here1")
                    completion(nil, error)
                }
                return
            }
            let decoder = JSONDecoder()
            do {
                let responseObject = try decoder.decode(LogoutResponse.self, from: data)
                DispatchQueue.main.async {
                    print("here2")
                    print(responseObject)
                    completion(responseObject, nil)
                }
            } catch {
                do {
                    let errorResponse = try decoder.decode(Session.self, from: data) as! Error
                    DispatchQueue.main.async {
                        print("here3")
                        print(errorResponse)
                        completion(nil, errorResponse)
                        
                    }
                } catch {
                    //let errorResponse1 = try decoder.decode(LoginErrorResponse.self, from: data) as Error
                    DispatchQueue.main.async {
                        print("here in logout 4")
                        completion(nil, error)
                        
                    }
                }
            }
            
            //*****************
        }
        task.resume()
        
        
    }
    
}
