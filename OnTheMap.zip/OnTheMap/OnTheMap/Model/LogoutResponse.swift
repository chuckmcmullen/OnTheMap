//
//  LogoutResponse.swift
//  OnTheMap
//
//  Created by Chuck McMullen on 3/28/21.
//

import Foundation
struct LogoutResponse: Codable {
    let session: Session
    
    
    enum CodingKeys: String, CodingKey
    {
        case session = "session"
        
        
    }
    
}
