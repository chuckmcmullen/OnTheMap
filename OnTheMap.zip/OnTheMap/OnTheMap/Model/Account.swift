//
//  Account.swift
//  OnTheMap
//
//  Created by Chuck McMullen on 2/19/21.
//

import Foundation
struct Account: Codable {
    
    let registered:Bool
    let key: String
    
    
    enum CodingKeys: String, CodingKey
    {
        case registered = "registered"
        case key = "key"
        
        
    }
    
}
