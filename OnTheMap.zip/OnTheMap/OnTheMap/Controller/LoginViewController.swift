//
//  ViewController.swift
//  OnTheMap
//
//  Created by Chuck McMullen on 2/16/21.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    var objectID:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        
        self.emailTextField.text = "1880browns@gmail.com"
        self.passwordTextField.text = "Dec1201$&@"
        //self.emailTextField.text = ""
        //self.passwordTextField.text = ""
    }
    
    @IBAction func loginButton(_ sender: Any) {
        
        
        let username = emailTextField.text!
        let password = passwordTextField.text!
        
        MapClient.login(username: String(describing: username) , password: String(describing: password) ,completion: self.handleLoginResponse(sessionID:success:error:))
        
        //MapClient.getStudentlist() { studentss, error in
            //StudentModel.studentlist = students
            //appDelegate.allStudents = studentss
            //print(StudentModel.studentlist[50].firstName)
        //}
        
        
        
    }
    
    
    
    @IBAction func updateButton(_ sender: Any) {
        
        print("update Student \(objectID)")
        //MapClient.updateStudentLoction(objectID: objectID)
        
        performSegue(withIdentifier: "tabView", sender: nil)
        
    }
    func handleLoginResponse(sessionID:String,success:Bool,error:Error?)
    {
        if(success)
        {
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            print("Success in handle login:")
            appDelegate.sessionID = sessionID;
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let mainTabBarController = storyboard.instantiateViewController(identifier: "TabViewController")
            mainTabBarController.modalPresentationStyle = .fullScreen
            
            self.present(mainTabBarController, animated: true, completion: nil)
            
        }
        else
        {
            print("Error test:\(String(describing: error?.localizedDescription))")
            let alertVC = UIAlertController(title: "Could not Login in", message: error?.localizedDescription, preferredStyle: .alert)
            alertVC.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            show(alertVC, sender: nil)
            
        }
    }
    
}
