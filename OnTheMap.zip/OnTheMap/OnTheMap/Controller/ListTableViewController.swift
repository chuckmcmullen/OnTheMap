//
//  ListTableViewController.swift
//  OnTheMap
//
//  Created by Chuck McMullen on 3/20/21.
//

import UIKit

class ListTableViewController: UITableViewController {
    var students = [Student]()
    override func viewDidLoad() {
        let finderIcon = UIImage(named: "Finder")
        let refreshIcon = UIImage(named: "Refresh")
        
        super.viewDidLoad()
        self.tableView.separatorStyle = UITableViewCell.SeparatorStyle.singleLine
        self.navigationItem.title = "On The Map"
        
        let finderButton   = UIBarButtonItem(image: finderIcon, style: UIBarButtonItem.Style.plain, target: self, action: #selector(informationPostingViewTapped))
        let logoutButton   = UIBarButtonItem(title:"Logout", style: UIBarButtonItem.Style.plain, target: self, action: #selector(logoutTapped))
        navigationItem.leftBarButtonItems = [finderButton, logoutButton]
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image:refreshIcon, style: UIBarButtonItem.Style.plain, target: self, action: #selector(refreshTapped))
        
        
        
    }
    override func viewDidAppear(_ animated: Bool) {
        print("viewdidapperar")
        refreshTapped()
        //self.tableView.reloadData()
        
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        //let appDelegate = UIApplication.shared.delegate as! AppDelegate
        //students = appDelegate.allStudents
        //students = self.students
        
        return students.count
        
        
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //var memes = Array<Any>()
        var student:Student
        //let appDelegate = UIApplication.shared.delegate as! AppDelegate
        //memes = appDelegate.memes
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell")!
        student = students[(indexPath as NSIndexPath).row] as! Student
        
        cell.textLabel?.text = student.firstName + " " + student.lastName
        cell.imageView?.image =  UIImage(named: "Finder")
        return cell
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //var student:Student
        //let appDelegate = UIApplication.shared.delegate as! AppDelegate
        //memes = appDelegate.memes
        //let detailController = self.storyboard!.instantiateViewController(withIdentifier: "MemeDetailViewController") as! MemeDetailViewController
        let student =  students[(indexPath as NSIndexPath).row] as? Student
        print(student!.mediaURL)
        if let url = URL(string: student!.mediaURL) {
            //UIApplication.shared.open(url, options: [:], completionHandler:nil)
            UIApplication.shared.open(url){ success in
                if !success {
                    print("Error in opening browser")
                    let alert = UIAlertController(title: "Invalid URL", message: student!.mediaURL, preferredStyle: .alert)

                    //alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: nil))
                    alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))

                    self.present(alert, animated: true)
                    
                }
            }
            
        }
        
        
        //self.navigationController!.pushViewController(detailController, animated: true)
        //let app = UIApplication.shared
        //if let toOpen = view.annotation?.subtitle! {
        //    app.openURL(URL(string: toOpen)!)
        //}
        
        
    }
    func handleURLResponse(success:Bool,error:Error?)
    {
        if(!success)
        {
            
            print("Error:")
            
            
        }
        
    }
    @objc func informationPostingViewTapped()
    {
        performSegue(withIdentifier: "InformationPostingView", sender: nil)
        
    }
    @objc func refreshTapped()
    {
        print("refresh")
        MapClient.getStudentlist() { students, error in
            self.students = students
            print(self.students[0].mapString)
            self.tableView.reloadData()
                
        }
        DispatchQueue.main.async(execute: {
                    self.tableView.reloadData()
                })
        //self.tableView.reloadData()
    }
    @objc func logoutTapped()
    {
        print("logout")
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        MapClient.logout(sessionID:String(describing: appDelegate.sessionID)){ success, error in
            if(success)
            {
                print("sucessfully logout")
                self.dismiss (animated: true, completion: nil)
                
            }
            else
            {
                print("error in logginout")
            }
        }
        
        
    }
    
}
