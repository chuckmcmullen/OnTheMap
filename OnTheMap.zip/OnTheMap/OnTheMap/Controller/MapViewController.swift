//
//  MapViewController.swift
//  OnTheMap
//
//  Created by Chuck McMullen on 3/20/21.
//

import UIKit
import MapKit

class MapViewController: UIViewController, UIGestureRecognizerDelegate, MKMapViewDelegate {
    var students = [Student]()
    
    @IBOutlet weak var mapView: MKMapView!

    override func viewDidLoad() {
        super.viewDidLoad()
    
        self.navigationItem.title = "On The Map"
        let finderIcon = UIImage(named: "Finder")
        let refreshIcon = UIImage(named: "Refresh")
        let finderButton   = UIBarButtonItem(image: finderIcon, style: UIBarButtonItem.Style.plain, target: self, action: #selector(informationPostingViewTapped))
        let logoutButton   = UIBarButtonItem(title:"Logout", style: UIBarButtonItem.Style.plain, target: self, action: #selector(logoutTapped))
        navigationItem.leftBarButtonItems = [finderButton, logoutButton]

        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image:refreshIcon, style: UIBarButtonItem.Style.plain, target: self, action: #selector(refreshTapped))
       
        mapView.delegate = self
        
        
        
    }
    override func viewDidAppear(_ animated: Bool) {
       
        self.refreshTapped()
         
    }
    override func viewWillAppear(_ animated: Bool) {
        
        
    }
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        let reuseId = "pin"
        
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView

        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = true
            pinView!.pinColor = .red
            pinView!.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        }
        else {
            pinView!.annotation = annotation
        }
        
        return pinView
    }
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        if control == view.rightCalloutAccessoryView {
            let app = UIApplication.shared
            if let toOpen = view.annotation?.subtitle! {
                app.openURL(URL(string: toOpen)!)
            }
        }
    }
    
    @objc func informationPostingViewTapped()
    {
        performSegue(withIdentifier: "InformationPostingView", sender: nil)
    }
    @objc func refreshTapped()
    {
        print("reload")
        
        
            MapClient.getStudentlist() { students, error in
                //StudentModel.studentlist = students
                self.students = students
                print(self.students[3].firstName)
            }
       
        DispatchQueue.main.async(execute: {
            self.removePins()
            self.fillMap()
        })
        
        
    }
    func fillMap()
    {
        
        let locations = self.students
        
        var annotations = [MKPointAnnotation]()
        
        for dictionary in locations {
            
            
            let lat = CLLocationDegrees(Double(dictionary.latitude) ?? 0)
            let long = CLLocationDegrees(Double(dictionary.longitude) ?? 0)
            
            // The lat and long are used to create a CLLocationCoordinates2D instance.
            let coordinate = CLLocationCoordinate2D(latitude: lat, longitude: long)
            
            let first = dictionary.firstName
            let last = dictionary.lastName
            let mediaURL = dictionary.mediaURL
            
            let annotation = MKPointAnnotation()
            annotation.coordinate = coordinate
            annotation.title = "\(first) \(last)"
            annotation.subtitle = mediaURL
            
            annotations.append(annotation)
        }
       
        self.mapView.addAnnotations(annotations)
        
    }
    func removePins() {
        for annotation in self.mapView.annotations {
            self.mapView.removeAnnotation(annotation)
        }
    }
    @objc func logoutTapped()
    {
        print("logout")
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        MapClient.logout(sessionID:String(describing: appDelegate.sessionID)){ success, error in
            if(success)
            {
                print("sucessfully logout")
                self.dismiss (animated: true, completion: nil)
                
            }
            else
            {
                print("error in logginout")
            }
        }
        
        
    }
}
