//
//  InformationPostingViewController.swift
//  OnTheMap
//
//  Created by Chuck McMullen on 3/22/21.
//

import UIKit
import MapKit
import CoreLocation

class InformationPostingViewController: UIViewController, UIGestureRecognizerDelegate,MKMapViewDelegate{
    
    @IBOutlet weak var locationTextBox: UITextField!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var locationButton: UIButton!
    @IBOutlet weak var urlTextBox: UITextField!
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var submitButton: UIButton!
    
    var objectID:String!
    var lat:String!
    var lon:String!
    var locationPlace:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title:"Cancel", style: UIBarButtonItem.Style.plain, target: self, action: #selector(cancelTapped))
        
        mapView.delegate = self
        hideShow(value: false)
    }
    @objc func cancelTapped()
    {
        dismiss (animated: true, completion: nil)
        
    }
    func hideShow(value:Bool)
    {
        titleLabel.isHidden = value
        locationTextBox.isHidden = value
        locationButton.isHidden = value
        urlTextBox.isHidden = !value
        mapView.isHidden = !value
        submitButton.isHidden = !value
    }
    @IBAction func submitButton(_ sender: Any) {
        MapClient.addStudentLoction(location:locationPlace,lat:self.lat,lon:self.lon,urlString:self.urlTextBox.text!, completion: handleAddStudentResponse(success:error:))
        
        dismiss (animated: true, completion: nil)
        
    }
    @IBAction func locationButton(_ sender: Any) {
        hideShow(value: true)
        self.locationPlace = self.locationTextBox.text
        findshowUserLocation(location: self.locationTextBox.text!)
        
    }
    func findshowUserLocation(location:String)
    {
        let geocoder = CLGeocoder()
        geocoder.geocodeAddressString(location) {
            placemarks, error in
            let placemark = placemarks?.first
            let lat = placemark?.location?.coordinate.latitude
            let lon = placemark?.location?.coordinate.longitude
            
            self.lat = String(lat!)
            self.lon = String(lon!)
            print("Lat: \(lat ?? 0.0), Lon: \(lon ?? 0.0)")
            self.placePin(lat: lat!, lon: lon!)
        }
        
    }
    func placePin(lat:Double,lon:Double)
    {
        
        var annotations:MKPointAnnotation
        
        let lat = CLLocationDegrees(Double(lat) ?? 0)
        let long = CLLocationDegrees(Double(lon) ?? 0)
        
        let coordinate = CLLocationCoordinate2D(latitude: lat, longitude: long)
        let viewRegion = MKCoordinateRegion(center: coordinate, latitudinalMeters: 500, longitudinalMeters: 500)
         
       
        let annotation = MKPointAnnotation()
        annotation.coordinate = coordinate
        //annotation.title = "\(first) \(last)"
        //annotation.subtitle = mediaURL
        self.mapView.addAnnotation(annotation)
        self.mapView.setRegion(viewRegion, animated: false)
        
    }
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        let reuseId = "pin"
        
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView

        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = true
            pinView!.pinColor = .red
            pinView!.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        }
        else {
            pinView!.annotation = annotation
        }
        
        return pinView
    }
    func handleAddStudentResponse(success:LocationResponse?,error:Error?)
    {
        if(error == nil)
        {
            
            objectID = success?.objectId ?? ""
            print("Success add student 1: \(objectID)")
        }
        else
        {
            print("Error test:\(error)")
        }
    }}
